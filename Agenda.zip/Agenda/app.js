
var  express = require("express"),
     app =  express(),
     mongoose       = require("mongoose"),
     bodyParser     = require("body-parser"),
     methodOverride = require("method-override"),
     Contact        = require("./models/contact"),
     seedDB         = require("./seeds");
     
    
    app.set("view engine", "ejs");
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(methodOverride("_method"));
    
    mongoose.connect("mongodb://localhost/agendApp", { useNewUrlParser: true});
     seedDB();

    
    // INICIO - CONTACT ROUTES----------------------------
    app.get("/", function(req, res){
        res.redirect("/contacts");
    });
    
    // INDEX ROUTE - SHOWS ALL CONTACTS
    app.get("/contacts", function(req, res){
        
        Contact.find({}, function(err, allcontacts){
            if(err){
                console.log("Error finding contacts");
            }else{
                // console.log("Contacts foundedยก");
                res.render("contacts/index", {contact: allcontacts});
            }
        });
    });
    
    app.get("/contacts/new", function(req, res){
        res.render("contacts/new");
    });

// CREATE ROUTE
    app.post("/contacts", function(req, res){
        Contact.create(req.body.contact, function(err, created){
            if(err){
                console.log("Error");
                res.redirect("/contacts");
            }else{
                console.log("Contact createdยก");
                res.redirect("/contacts");
            }
        });
    });
    
//SHOW ROUTE    
    app.get("/contacts/:id", function(req, res){
        Contact.findById(req.params.id, function(err, founded){
           if(err){
               console.log("ERROR finding id");
               res.redirect("/contacts");
           }else{        
             res.render("contacts/show", {contact: founded});  
           }
        });
    });
    
//EDIT ROUTE - OPENS A NEW FORM TO EDIT A CONTACT
app.get("/contacts/:id/edit", function(req, res){
    Contact.findById(req.params.id, function(err, founded){
        if(err){
            console.log("ERROR"); res.redirect("/contacts");
        }else{
            res.render("contacts/edit", {contacts: founded});
        }
    });
});

// UPDATE ROUTE - UPDATES A PARTICULAR CONTACT
app.put("/contacts/:id", function(req, res){
    Contact.findByIdAndUpdate(req.params.id, req.body.contacts, function(err, updated){
        if(err){
            console.log("ERROR UPDATING"); res.redirect("/contacts");
        }else{
            console.log("Update Successful");
            res.redirect("/contacts/"+req.params.id);
        }
    });
});

// DESTROY ROUTE - FINDS AN ELEMENT - REDIRECT SOMEWHERE
app.delete("/contacts/:id", function(req, res){
    
    Contact.findByIdAndRemove(req.params.id, function(err){
        if(err){
            console.log("ERROR deleting");
            res.redirect("/contacts");
        }else{
            console.log("Contact deleted");
            res.redirect("/contacts");
        }
    });
});
    
    // FIN - DEFINING ROUTES------------------------------
    
    
    //iniciando el server
    app.listen(3000, function(){
        console.log("AGENDA SERVER RUNNING");
    });