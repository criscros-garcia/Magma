var mongoose = require("mongoose");
var Contact = require("./models/contact");


var data = [
    {   name	 : "Cristian Garcia",
        phone    : "3123094559",
	 	email    : "eminemko@hotmail.com"
    },
    {   name	 : "Contacto 2",
        phone    : "31230945255",
	 	email    : "correo@hotmail.com"
        
    },
    {
        name	 : "Contacto 3",
        phone    : "31230945235",
	 	email    : "correo3@hotmail.com"
    }
    ];
    
    function seedDB(){      
    
        
        Contact.deleteMany({},function(err){
            if(err){
                console.log("ERROR");
            }else{
                
                    console.log("Contacts RESET");
                    
                    data.forEach(function(seed){
                        Contact.create(seed, function(err, contactCreated){
                                if(err){
                                    console.log("ERROR CREATING CONTACTยก");
                                } else{
                                        console.log("CONTACT created¡");                                      
                                    }
                        });    
                    });
                }
            
        });
    }
    
    module.exports = seedDB;