var mongoose = require("mongoose");

    var contactSchema = new mongoose.Schema({
        name:  String,
        phone: String,
        email: String,
    });
    
//exportas el modelo y en app.js lo requieres
module.exports = mongoose.model("Contact", contactSchema);




